(()=>{
  const BRAND_MAIN='TONGJUN';
  const BRAND_SUB='METAL TECH · EST. 2026';
  const LEGACY_BRAND='TONGJUN METAL TECH';
  const LOCAL={
    'og-social.webp':'/assets/images/r15-6-materials.webp?v=20260920-r15-6b',
    'precision-strip.webp':'/assets/images/r15-6-precision.webp?v=20260920-r15-6b',
    'nickel-alloys.webp':'/assets/images/r15-6-process.webp?v=20260920-r15-6b',
    'heavy-plate.webp':'/assets/images/r15-6-heavy.webp?v=20260920-r15-6b',
    'invar-lng.webp':'/assets/images/r15-6-lng.webp?v=20260920-r15-6b',
    'invar-tooling.webp':'/assets/images/r15-6-tooling.webp?v=20260920-r15-6b',
    'titanium-zirconium.webp':'/assets/images/r15-6-titanium.webp?v=20260920-r15-6b',
    'about-engineering.webp':'/assets/images/r15-6-about.webp?v=20260920-r15-6b',
    'quality-inspection.webp':'/assets/images/r15-6-quality.webp?v=20260920-r15-6b',
    'traceability-pmi.webp':'/assets/images/r15-6-quality.webp?v=20260920-r15-6b',
    'resources-metal.webp':'/assets/images/r15-6-materials.webp?v=20260920-r15-6b',
    'standards-rfq.webp':'/assets/images/r15-6-quality.webp?v=20260920-r15-6b'
  };

  function normalizeBrandLockup(root){
    if(!root) return;
    const composite=root.querySelector(':scope > .tj-brand-composite');
    if(composite){
      const strong=composite.querySelector('.tj-brand-copy strong');
      const small=composite.querySelector('.tj-brand-copy small');
      if(strong) strong.textContent=BRAND_MAIN;
      if(small) small.textContent=BRAND_SUB;
      return;
    }
    // Legacy markup only: never target the vector composite container itself.
    const label=root.querySelector(':scope > span:last-child:not(.tj-brand-composite)');
    if(label) label.textContent=LEGACY_BRAND;
  }

  function normalizeHeader(){
    const brand=document.querySelector('.site-header .brand');
    if(brand){
      brand.setAttribute('aria-label','Tongjun Metal Tech home');
      normalizeBrandLockup(brand);
    }
  }

  function normalizeFooter(){
    document.querySelectorAll('.site-footer .brand,footer .brand').forEach(normalizeBrandLockup);
  }

  function basename(src){
    try{return new URL(src,location.href).pathname.split('/').pop()||''}
    catch{return String(src||'').split('/').pop()||''}
  }

  function applyFallback(img){
    if(!img||img.dataset.tjFallbackApplied==='1') return;
    const key=basename(img.getAttribute('src')||img.currentSrc||'');
    const fallback=LOCAL[key];
    if(!fallback) return;
    img.dataset.tjFallbackApplied='1';
    img.classList.add('tj-image-fallback');
    img.dataset.originalAsset=key;
    img.src=fallback;
  }

  function recoverImages(){
    document.querySelectorAll('img').forEach(img=>{
      const raw=img.getAttribute('src')||'';
      if(!/assets\/images\//.test(raw)) return;
      img.addEventListener('error',()=>applyFallback(img),{once:true});
      if(img.complete&&img.naturalWidth===0) applyFallback(img);
    });
  }

  function removeFloatingBots(){
    const selectors=['#dify-chatbot-bubble-button','#dify-chatbot-bubble-window','iframe[src*="dify"]','iframe[src*="chatbot"]','iframe[src*="coze"]','.chatbot-bubble','.floating-chatbot','.floating-assistant'];
    document.querySelectorAll(selectors.join(',')).forEach(el=>el.remove());
    const observer=new MutationObserver(()=>document.querySelectorAll(selectors.join(',')).forEach(el=>el.remove()));
    observer.observe(document.documentElement,{childList:true,subtree:true});
    setTimeout(()=>observer.disconnect(),12000);
  }

  document.addEventListener('DOMContentLoaded',()=>{
    normalizeHeader();
    normalizeFooter();
    recoverImages();
    removeFloatingBots();
  });
})();
